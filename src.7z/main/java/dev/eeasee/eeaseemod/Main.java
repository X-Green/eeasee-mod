package dev.eeasee.eeaseemod;

import dev.eeasee.clientcommands.CommandHandler;
import dev.eeasee.eeaseemod.commands.CommandEeaseemodSettings;
import dev.eeasee.eeaseemod.commands.CommandMenu;
import dev.eeasee.eeaseemod.config.ConfigHandler;
import dev.eeasee.eeaseemod.config.Configs;
import dev.eeasee.eeaseemod.events.OnClientTick;
import fi.dy.masa.malilib.config.ConfigManager;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.client.keybinding.FabricKeyBinding;
import net.fabricmc.fabric.api.event.client.ClientTickCallback;
import net.fabricmc.fabric.impl.client.keybinding.KeyBindingRegistryImpl;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.util.InputUtil;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.util.Identifier;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

public class Main implements ModInitializer {


	public static final String MOD_ID = "eeaseemod";

	public static final FabricKeyBinding MASTER_CONTROL = FabricKeyBinding.Builder.create(
			new Identifier(MOD_ID, "master_control"),
			InputUtil.Type.KEYSYM,
			InputUtil.fromName("key.keyboard.u").getKeyCode(),
			"key.categories.ui").build();

	public static final CommandHandler ClientCommandManager = new CommandHandler();

	public static MinecraftClient client;

	public static Map<String, EntityType> entityTypeMap = new HashMap<>();

	@Override
	public void onInitialize() {
		// This code runs as soon as Minecraft is in a mod-load-ready state.
		// However, some things (like resources) may still be uninitialized.
		// Proceed with mild caution.

		System.out.println("It's so eeasee!");
		ClientTickCallback.EVENT.register(new OnClientTick());

		ConfigManager.getInstance().registerConfigHandler(MOD_ID, new ConfigHandler());
		new Configs();
		ConfigHandler.loadFile();
		KeyBindingRegistryImpl.INSTANCE.register(MASTER_CONTROL);

		ClientCommandManager.setPrefix("..");
		registerCommands();

	}

	private void registerCommands() {
		ClientCommandManager.register("eeaseemod-settings", new CommandEeaseemodSettings());
		ClientCommandManager.register("menu", new CommandMenu());
	}


}
