package dev.eeasee.eeaseemod.mixin;

import dev.eeasee.eeaseemod.Main;
import net.minecraft.client.network.ClientPlayNetworkHandler;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.network.Packet;
import net.minecraft.network.packet.c2s.play.ChatMessageC2SPacket;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

@Mixin(ClientPlayerEntity.class)
public abstract class ClientPlayerEntityMixin {
    @Redirect(
            method = "sendChatMessage",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/client/network/ClientPlayNetworkHandler;sendPacket(Lnet/minecraft/network/Packet;)V")
    )
    private void handleChatMessage(ClientPlayNetworkHandler clientPlayNetworkHandler, Packet<?> packet){
        if (Main.ClientCommandManager.isChatMessageToBeSent((ChatMessageC2SPacket) packet, (ClientPlayerEntity)(Object)this)){
            clientPlayNetworkHandler.sendPacket(packet);
        }
    }
}
